#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$SCRIPT_DIR"

echo "========================================================================"
echo " Building Google Test Suite with GCOV Coverage Instrumentation..."
echo "========================================================================"

mkdir -p build_coverage
cd build_coverage

g++ -std=c++17 -O0 -g3 -DUNIT_TESTING=1 --coverage -fprofile-arcs -ftest-coverage \
    -I../../include ../test_chs.cpp ../../src/main.c \
    -lgtest -lgtest_main -lssl -lcrypto -pthread -o chs_coverage_tests

echo "========================================================================"
echo " Executing Tests to Generate Coverage Trace Files..."
echo "========================================================================"

./chs_coverage_tests --gtest_color=yes

echo "========================================================================"
echo " Generating GCOV Code Coverage Report for Production Source..."
echo "========================================================================"

gcov -b -c chs_coverage_tests-main.gcno

mkdir -p "$ROOT_DIR/reports/coverage"
if command -v gcovr >/dev/null 2>&1; then
    gcovr -r "$ROOT_DIR" "$SCRIPT_DIR/build_coverage" --filter '.*/src/.*' --txt "$ROOT_DIR/reports/coverage/coverage_summary.txt" || true
    gcovr -r "$ROOT_DIR" "$SCRIPT_DIR/build_coverage" --filter '.*/src/.*' --html --html-details -o "$ROOT_DIR/reports/coverage/index.html" || true
    echo "========================================================================"
    echo " Summary Report:"
    cat "$ROOT_DIR/reports/coverage/coverage_summary.txt" 2>/dev/null || true
    echo "========================================================================"
fi
