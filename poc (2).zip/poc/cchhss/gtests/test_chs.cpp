#include <gtest/gtest.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>

#define UNIT_TESTING 1
#include "../include/complaint_system.h"

extern "C" {
    extern CustomerNode *customerHead;
    extern ComplaintNode *complaintHead;
    extern Agent agents[MAX_AGENTS];
    extern Manager managerAccount;
    extern int nextComplaintNum;
    extern int nextCustomerNum;
    extern int systemRunning;
    extern pthread_mutex_t dataMutex;
    extern pthread_cond_t systemCond;
}

/* Helper RAII class to redirect stdin for testing interactive menu and input functions */
class RedirectStdin {
    int oldStdin;
    int pipeFds[2];
public:
    explicit RedirectStdin(const std::string& input) {
        if (pipe(pipeFds) == 0) {
            ssize_t written = write(pipeFds[1], input.c_str(), input.length());
            (void)written;
            close(pipeFds[1]);
            oldStdin = dup(STDIN_FILENO);
            dup2(pipeFds[0], STDIN_FILENO);
            close(pipeFds[0]);
        } else {
            oldStdin = -1;
        }
    }
    ~RedirectStdin() {
        if (oldStdin != -1) {
            dup2(oldStdin, STDIN_FILENO);
            close(oldStdin);
        }
    }
};

/* Helper RAII class to capture stdout during console output tests */
class CaptureStdout {
    int oldStdout;
    int pipeFds[2];
public:
    CaptureStdout() {
        if (pipe(pipeFds) == 0) {
            oldStdout = dup(STDOUT_FILENO);
            dup2(pipeFds[1], STDOUT_FILENO);
            close(pipeFds[1]);
        } else {
            oldStdout = -1;
        }
    }
    std::string getOutput() {
        fflush(stdout);
        char buf[8192];
        ssize_t n = read(pipeFds[0], buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = '\0';
            return std::string(buf);
        }
        return "";
    }
    ~CaptureStdout() {
        if (oldStdout != -1) {
            dup2(oldStdout, STDOUT_FILENO);
            close(oldStdout);
            close(pipeFds[0]);
        }
    }
};

/* Test Fixture ensuring pristine isolated filesystem and memory state per test */
class CHSTestFixture : public ::testing::Test {
protected:
    std::string testDir;
    char origCwd[1024];

    void SetUp() override {
        if (getcwd(origCwd, sizeof(origCwd)) == nullptr) {
            origCwd[0] = '\0';
        }
        char tempPath[] = "/tmp/chs_test_XXXXXX";
        char *d = mkdtemp(tempPath);
        if (d != nullptr) {
            testDir = d;
            (void)chdir(testDir.c_str());
            (void)mkdir("data", 0755);
        }
        freeAllMemory();
        customerHead = NULL;
        complaintHead = NULL;
        nextComplaintNum = 101;
        nextCustomerNum = 1001;
        systemRunning = 1;
    }

    void TearDown() override {
        freeAllMemory();
        if (origCwd[0] != '\0') {
            (void)chdir(origCwd);
        }
        if (!testDir.empty()) {
            std::string cmd = "rm -rf " + testDir;
            (void)system(cmd.c_str());
        }
    }
};

/* ========================================================================= */
/* SUITE 1: InputValidationTest (Functions: getTimestamp, readString, readInt) */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC01_GetTimestamp_ValidBuffer_FormatsStandardTimestamp) {
    char buf[64];
    getTimestamp(buf, sizeof(buf));
    EXPECT_GT(strlen(buf), 10U);
    EXPECT_EQ(buf[4], '-');
    EXPECT_EQ(buf[7], '-');
    EXPECT_EQ(buf[10], ' ');
}

TEST_F(CHSTestFixture, TC02_GetTimestamp_NullBuffer_HandlesSafelyWithoutCrashing) {
    EXPECT_NO_FATAL_FAILURE(getTimestamp(NULL, 64));
}

TEST_F(CHSTestFixture, TC03_GetTimestamp_ZeroSize_HandlesSafely) {
    char buf[16] = "Test";
    EXPECT_NO_FATAL_FAILURE(getTimestamp(buf, 0));
    EXPECT_STREQ(buf, "Test");
}

TEST_F(CHSTestFixture, TC04_ReadString_SanitizesPipesToHyphens) {
    RedirectStdin input("Alpha|Beta|Gamma\n");
    char buf[64];
    readString("", buf, sizeof(buf));
    EXPECT_STREQ(buf, "Alpha-Beta-Gamma");
}

TEST_F(CHSTestFixture, TC05_ReadString_NullBufferOrZeroSize_HandlesSafely) {
    RedirectStdin input("Sample\n");
    EXPECT_NO_FATAL_FAILURE(readString("", NULL, 0));
}

TEST_F(CHSTestFixture, TC06_ReadInt_ValidInput_ParsesCorrectly) {
    RedirectStdin input("3\n");
    int val = readInt("", 1, 5);
    EXPECT_EQ(val, 3);
}

TEST_F(CHSTestFixture, TC07_ReadInt_OutOfRange_RetriesUntilValid) {
    RedirectStdin input("99\n-5\n2\n");
    CaptureStdout capture;
    int val = readInt("", 1, 5);
    EXPECT_EQ(val, 2);
}

/* ========================================================================= */
/* SUITE 2: PasswordHashingTest (Functions: hashPassword, verifyPassword)    */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC08_HashPassword_ValidInput_GeneratesValidPBKDF2Hash) {
    char hash[PASSWORD_HASH_LEN];
    int res = hashPassword("SecretP@ss123", NULL, PBKDF2_ITERATIONS, hash, sizeof(hash));
    EXPECT_EQ(res, 1);
    EXPECT_EQ(strncmp(hash, "$pbkdf2-sha256$i=10000$", 23), 0);
}

TEST_F(CHSTestFixture, TC09_HashPassword_EmptyPassword_ReturnsFailure) {
    char hash[PASSWORD_HASH_LEN];
    int res = hashPassword("", NULL, PBKDF2_ITERATIONS, hash, sizeof(hash));
    EXPECT_EQ(res, 0);
}

TEST_F(CHSTestFixture, TC10_HashPassword_InvalidIterations_ReturnsFailure) {
    char hash[PASSWORD_HASH_LEN];
    int res = hashPassword("pass", NULL, 0, hash, sizeof(hash));
    EXPECT_EQ(res, 0);
}

TEST_F(CHSTestFixture, TC11_HashPassword_SmallOutputBuffer_ReturnsFailure) {
    char smallBuf[32];
    int res = hashPassword("pass", NULL, PBKDF2_ITERATIONS, smallBuf, sizeof(smallBuf));
    EXPECT_EQ(res, 0);
}

TEST_F(CHSTestFixture, TC12_HashPassword_IdenticalPasswords_DifferentSalts_ProduceDifferentHashes) {
    char hash1[PASSWORD_HASH_LEN];
    char hash2[PASSWORD_HASH_LEN];
    ASSERT_EQ(hashPassword("password123", NULL, PBKDF2_ITERATIONS, hash1, sizeof(hash1)), 1);
    ASSERT_EQ(hashPassword("password123", NULL, PBKDF2_ITERATIONS, hash2, sizeof(hash2)), 1);
    EXPECT_STRNE(hash1, hash2);
}

TEST_F(CHSTestFixture, TC13_HashPassword_CustomSalt_ProducesConsistentHash) {
    const char *customSalt = "0123456789abcdef0123456789abcdef";
    char hash1[PASSWORD_HASH_LEN];
    char hash2[PASSWORD_HASH_LEN];
    ASSERT_EQ(hashPassword("samepass", customSalt, 5000, hash1, sizeof(hash1)), 1);
    ASSERT_EQ(hashPassword("samepass", customSalt, 5000, hash2, sizeof(hash2)), 1);
    EXPECT_STREQ(hash1, hash2);
}

TEST_F(CHSTestFixture, TC14_VerifyPassword_CorrectPassword_ReturnsSuccess) {
    char hash[PASSWORD_HASH_LEN];
    ASSERT_EQ(hashPassword("MyPass999", NULL, PBKDF2_ITERATIONS, hash, sizeof(hash)), 1);
    EXPECT_EQ(verifyPassword("MyPass999", hash), 1);
}

TEST_F(CHSTestFixture, TC15_VerifyPassword_IncorrectPassword_ReturnsFailure) {
    char hash[PASSWORD_HASH_LEN];
    ASSERT_EQ(hashPassword("RealPassword", NULL, PBKDF2_ITERATIONS, hash, sizeof(hash)), 1);
    EXPECT_EQ(verifyPassword("WrongPassword", hash), 0);
}

TEST_F(CHSTestFixture, TC16_VerifyPassword_MalformedStoredHash_ReturnsFailure) {
    EXPECT_EQ(verifyPassword("pass", "$pbkdf2-sha256$malformed$data"), 0);
}

TEST_F(CHSTestFixture, TC17_VerifyPassword_InvalidSaltLength_ReturnsFailure) {
    const char *badSaltHash = "$pbkdf2-sha256$i=10000$0123456789$abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
    EXPECT_EQ(verifyPassword("pass", badSaltHash), 0);
}

TEST_F(CHSTestFixture, TC18_VerifyPassword_InvalidHashLength_ReturnsFailure) {
    const char *badHashLen = "$pbkdf2-sha256$i=10000$0123456789abcdef0123456789abcdef$0123456789abcdef";
    EXPECT_EQ(verifyPassword("pass", badHashLen), 0);
}

TEST_F(CHSTestFixture, TC19_VerifyPassword_LegacyPlaintextMatch_ReturnsLegacyFlag) {
    EXPECT_EQ(verifyPassword("agentpass1", "agentpass1"), 2);
}

/* ========================================================================= */
/* SUITE 3: CustomerSearchTest (Function: findCustomerByUsername)             */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC20_FindCustomerByUsername_ExistingUser_ReturnsNode) {
    CustomerNode *node = (CustomerNode *)malloc(sizeof(CustomerNode));
    ASSERT_NE(node, nullptr);
    strcpy(node->data.customerId, "CUST1001");
    strcpy(node->data.username, "john_doe");
    node->next = NULL;
    customerHead = node;

    CustomerNode *found = findCustomerByUsername("john_doe");
    ASSERT_NE(found, nullptr);
    EXPECT_STREQ(found->data.customerId, "CUST1001");
}

TEST_F(CHSTestFixture, TC21_FindCustomerByUsername_NonExistentUser_ReturnsNull) {
    EXPECT_EQ(findCustomerByUsername("unknown_user"), nullptr);
}

TEST_F(CHSTestFixture, TC22_FindCustomerByUsername_NullOrEmpty_ReturnsNull) {
    EXPECT_EQ(findCustomerByUsername(NULL), nullptr);
    EXPECT_EQ(findCustomerByUsername(""), nullptr);
}

/* ========================================================================= */
/* SUITE 4: ComplaintSearchTest (Function: findComplaintById)                */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC23_FindComplaintById_ExistingId_ReturnsNode) {
    ComplaintNode *node = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    ASSERT_NE(node, nullptr);
    memset(&node->data, 0, sizeof(Complaint));
    strcpy(node->data.complaintId, "CMP101");
    node->auditHead = NULL;
    node->next = NULL;
    complaintHead = node;

    ComplaintNode *found = findComplaintById("CMP101");
    ASSERT_NE(found, nullptr);
    EXPECT_STREQ(found->data.complaintId, "CMP101");
}

TEST_F(CHSTestFixture, TC24_FindComplaintById_NonExistentId_ReturnsNull) {
    EXPECT_EQ(findComplaintById("CMP999"), nullptr);
}

TEST_F(CHSTestFixture, TC25_FindComplaintById_NullOrEmptyId_ReturnsNull) {
    EXPECT_EQ(findComplaintById(NULL), nullptr);
    EXPECT_EQ(findComplaintById(""), nullptr);
}

/* ========================================================================= */
/* SUITE 5: AuditHistoryTest (Function: addAuditEntry)                       */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC26_AddAuditEntry_FirstEntry_CreatesAuditHead) {
    ComplaintNode *node = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    ASSERT_NE(node, nullptr);
    memset(&node->data, 0, sizeof(Complaint));
    strcpy(node->data.complaintId, "CMP101");
    node->auditHead = NULL;
    node->next = NULL;

    addAuditEntry(node, "REGISTERED", "CUST1001", "Initial complaint filed");
    ASSERT_NE(node->auditHead, nullptr);
    EXPECT_STREQ(node->auditHead->action, "REGISTERED");
    EXPECT_STREQ(node->auditHead->performedBy, "CUST1001");
    EXPECT_STREQ(node->auditHead->details, "Initial complaint filed");

    free(node->auditHead);
    free(node);
}

TEST_F(CHSTestFixture, TC27_AddAuditEntry_MultipleEntries_AppendsInChronologicalOrder) {
    ComplaintNode *node = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    ASSERT_NE(node, nullptr);
    memset(&node->data, 0, sizeof(Complaint));
    strcpy(node->data.complaintId, "CMP101");
    node->auditHead = NULL;
    node->next = NULL;

    addAuditEntry(node, "ACTION1", "BY1", "Det1");
    addAuditEntry(node, "ACTION2", "BY2", "Det2");

    ASSERT_NE(node->auditHead, nullptr);
    ASSERT_NE(node->auditHead->next, nullptr);
    EXPECT_STREQ(node->auditHead->action, "ACTION1");
    EXPECT_STREQ(node->auditHead->next->action, "ACTION2");

    free(node->auditHead->next);
    free(node->auditHead);
    free(node);
}

TEST_F(CHSTestFixture, TC28_AddAuditEntry_NullNode_HandlesSafely) {
    EXPECT_NO_FATAL_FAILURE(addAuditEntry(NULL, "ACTION", "BY", "Details"));
}

TEST_F(CHSTestFixture, TC29_AddAuditEntry_NullDetailsOrBy_DefaultsSafely) {
    ComplaintNode *node = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    ASSERT_NE(node, nullptr);
    memset(&node->data, 0, sizeof(Complaint));
    strcpy(node->data.complaintId, "CMP101");
    node->auditHead = NULL;
    node->next = NULL;

    addAuditEntry(node, NULL, NULL, NULL);
    ASSERT_NE(node->auditHead, nullptr);
    EXPECT_STREQ(node->auditHead->action, "ACTION");
    EXPECT_STREQ(node->auditHead->performedBy, "SYSTEM");
    EXPECT_STREQ(node->auditHead->details, "");

    free(node->auditHead);
    free(node);
}

/* ========================================================================= */
/* SUITE 6: AgentAssignmentTest (Function: autoAssignAgent)                   */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC30_AutoAssignAgent_BalancedWorkload_AssignsToLeastLoaded) {
    for (int i = 0; i < MAX_AGENTS; ++i) {
        snprintf(agents[i].agentId, sizeof(agents[i].agentId), "AGT%03d", 101 + i);
        agents[i].isActive = 1;
    }

    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.status, "IN_PROGRESS");
    strcpy(c1->data.assignedAgentId, "AGT101");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    int assignedIdx = autoAssignAgent();
    EXPECT_EQ(assignedIdx, 1);
}

TEST_F(CHSTestFixture, TC31_AutoAssignAgent_AllAgentsInactive_ReturnsNegativeOne) {
    for (int i = 0; i < MAX_AGENTS; ++i) {
        agents[i].isActive = 0;
    }
    EXPECT_EQ(autoAssignAgent(), -1);
}

TEST_F(CHSTestFixture, TC32_AutoAssignAgent_EqualWorkload_TieBreaksToLowestIndex) {
    for (int i = 0; i < MAX_AGENTS; ++i) {
        snprintf(agents[i].agentId, sizeof(agents[i].agentId), "AGT%03d", 101 + i);
        agents[i].isActive = 1;
    }
    EXPECT_EQ(autoAssignAgent(), 0);
}

/* ========================================================================= */
/* SUITE 7: SystemInitializationTest (Function: initSystem)                  */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC33_InitSystem_MissingFiles_CreatesDefaultAgentsWithHashedPasswords) {
    initSystem();
    EXPECT_EQ(nextComplaintNum, 101);
    EXPECT_EQ(nextCustomerNum, 1001);
    EXPECT_STREQ(agents[0].agentId, "AGT101");
    EXPECT_EQ(agents[0].isActive, 1);
    EXPECT_EQ(strncmp(agents[0].password, "$pbkdf2-sha256$", 15), 0);
}

TEST_F(CHSTestFixture, TC34_InitSystem_CountersFileLoaded_SetsCorrectNextNumbers) {
    std::ofstream f("data/counters.txt");
    f << "150\n2050\n";
    f.close();

    initSystem();
    EXPECT_EQ(nextComplaintNum, 150);
    EXPECT_EQ(nextCustomerNum, 2050);
}

TEST_F(CHSTestFixture, TC35_InitSystem_CountersFileCorrupted_ResetsToDefaults) {
    std::ofstream f("data/counters.txt");
    f << "corrupted_text\n";
    f.close();

    initSystem();
    EXPECT_EQ(nextComplaintNum, 101);
    EXPECT_EQ(nextCustomerNum, 1001);
}

TEST_F(CHSTestFixture, TC36_InitSystem_AgentsFileWithLegacyPlaintext_MigratesToPBKDF2Hashes) {
    std::ofstream f("data/agents.txt");
    f << "AGT101|Alice Smith|agent1|plaintextpass123|1|0\n";
    f.close();

    initSystem();
    EXPECT_STREQ(agents[0].agentId, "AGT101");
    EXPECT_EQ(strncmp(agents[0].password, "$pbkdf2-sha256$", 15), 0);
    EXPECT_EQ(verifyPassword("plaintextpass123", agents[0].password), 1);
}

TEST_F(CHSTestFixture, TC37_InitSystem_ManagerFileMissing_InitializesHashedManagerCredential) {
    initSystem();
    EXPECT_STREQ(managerAccount.username, "manager");
    EXPECT_EQ(strncmp(managerAccount.password, "$pbkdf2-sha256$", 15), 0);
    EXPECT_EQ(verifyPassword("manager123", managerAccount.password), 1);
}

/* ========================================================================= */
/* SUITE 8: PersistenceTest (Function: saveAllData)                          */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC38_SaveAllData_PersistsCustomersAgentsComplaintsAudit) {
    initSystem();
    saveAllData();

    struct stat st;
    EXPECT_EQ(stat("data/counters.txt", &st), 0);
    EXPECT_EQ(stat("data/agents.txt", &st), 0);
    EXPECT_EQ(stat("data/customers.txt", &st), 0);
    EXPECT_EQ(stat("data/complaints.txt", &st), 0);
    EXPECT_EQ(stat("data/audit_log.txt", &st), 0);
    EXPECT_EQ(stat("data/manager.txt", &st), 0);
}

TEST_F(CHSTestFixture, TC39_SaveAllData_PersistsManagerWithRestrictedPermissions) {
    initSystem();
    saveAllData();

    struct stat st;
    ASSERT_EQ(stat("data/manager.txt", &st), 0);
#ifndef _WIN32
    EXPECT_EQ(st.st_mode & 0777, 0600);
#endif
}

TEST_F(CHSTestFixture, TC40_SaveAllData_ZeroPlaintextPasswordsInSavedFiles) {
    initSystem();
    saveAllData();

    std::ifstream fAgent("data/agents.txt");
    std::string line;
    while (std::getline(fAgent, line)) {
        EXPECT_EQ(line.find("agentpass"), std::string::npos);
        EXPECT_NE(line.find("$pbkdf2-sha256$"), std::string::npos);
    }
}

TEST_F(CHSTestFixture, TC41_SaveAndReload_MaintainsDataIntegrityAcrossRestarts) {
    initSystem();
    nextComplaintNum = 222;
    nextCustomerNum = 3333;
    saveAllData();

    freeAllMemory();
    initSystem();
    EXPECT_EQ(nextComplaintNum, 222);
    EXPECT_EQ(nextCustomerNum, 3333);
}

/* ========================================================================= */
/* SUITE 9: MemoryCleanupTest (Function: freeAllMemory)                      */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC42_FreeAllMemory_FreesAllCustomerComplaintAndAuditNodes) {
    CustomerNode *cNode = (CustomerNode *)malloc(sizeof(CustomerNode));
    memset(&cNode->data, 0, sizeof(Customer));
    cNode->next = NULL;
    customerHead = cNode;

    ComplaintNode *compNode = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&compNode->data, 0, sizeof(Complaint));
    compNode->auditHead = NULL;
    compNode->next = NULL;
    complaintHead = compNode;
    addAuditEntry(compNode, "TEST", "USER", "Note");

    freeAllMemory();
    EXPECT_EQ(customerHead, nullptr);
    EXPECT_EQ(complaintHead, nullptr);
}

TEST_F(CHSTestFixture, TC43_FreeAllMemory_EmptyLists_HandlesSafelyWithoutErrors) {
    customerHead = NULL;
    complaintHead = NULL;
    EXPECT_NO_FATAL_FAILURE(freeAllMemory());
    EXPECT_EQ(customerHead, nullptr);
    EXPECT_EQ(complaintHead, nullptr);
}

/* ========================================================================= */
/* SUITE 10: ThreadSafetyTest (Function: monitoringThread)                   */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC44_MonitoringThread_DetectsEscalatedComplaintsUnderMutex) {
    ComplaintNode *node = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    ASSERT_NE(node, nullptr);
    memset(&node->data, 0, sizeof(Complaint));
    strcpy(node->data.complaintId, "CMP101");
    strcpy(node->data.status, "ESCALATED");
    node->auditHead = NULL;
    node->next = NULL;
    complaintHead = node;

    systemRunning = 1;
    pthread_t thread;
    ASSERT_EQ(pthread_create(&thread, NULL, monitoringThread, NULL), 0);

    usleep(50000); /* 50ms */

    pthread_mutex_lock(&dataMutex);
    systemRunning = 0;
    pthread_cond_broadcast(&systemCond);
    pthread_mutex_unlock(&dataMutex);

    pthread_join(thread, NULL);
}

TEST_F(CHSTestFixture, TC45_MonitoringThread_CleanShutdownSignal_TerminatesWithoutDelay) {
    systemRunning = 1;
    pthread_t thread;
    ASSERT_EQ(pthread_create(&thread, NULL, monitoringThread, NULL), 0);

    pthread_mutex_lock(&dataMutex);
    systemRunning = 0;
    pthread_cond_broadcast(&systemCond);
    pthread_mutex_unlock(&dataMutex);

    ASSERT_EQ(pthread_join(thread, NULL), 0);
}

/* ========================================================================= */
/* SUITE 11: CustomerMenuTest (Function: customerMenu)                       */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC46_CustomerMenu_NavigationAndReturnToMain) {
    RedirectStdin input("3\n"); /* Return to main menu */
    CaptureStdout capture;
    EXPECT_NO_FATAL_FAILURE(customerMenu());
}

/* ========================================================================= */
/* SUITE 12: CustomerRegistrationTest (Function: customerRegister)           */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC47_CustomerRegister_ValidDetails_CreatesAccountWithHashedPassword) {
    RedirectStdin input("Jane Doe\njanedoe\npassJane123\njane@example.com\n");
    CaptureStdout capture;
    customerRegister();

    CustomerNode *node = findCustomerByUsername("janedoe");
    ASSERT_NE(node, nullptr);
    EXPECT_STREQ(node->data.fullName, "Jane Doe");
    EXPECT_EQ(strncmp(node->data.password, "$pbkdf2-sha256$", 15), 0);
    EXPECT_EQ(verifyPassword("passJane123", node->data.password), 1);
}

TEST_F(CHSTestFixture, TC48_CustomerRegister_DuplicateUsername_RejectsRegistration) {
    CustomerNode *cNode = (CustomerNode *)malloc(sizeof(CustomerNode));
    memset(&cNode->data, 0, sizeof(Customer));
    strcpy(cNode->data.customerId, "CUST1001");
    strcpy(cNode->data.username, "existinguser");
    cNode->next = NULL;
    customerHead = cNode;

    RedirectStdin input("New Name\nexistinguser\n");
    CaptureStdout capture;
    customerRegister();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("already taken"), std::string::npos);
}

TEST_F(CHSTestFixture, TC49_CustomerRegister_BlankFields_AbortsGracefully) {
    RedirectStdin input("\n");
    CaptureStdout capture;
    customerRegister();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Registration cancelled"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 13: CustomerLoginTest (Function: customerLogin)                     */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC50_CustomerLogin_ValidCredentials_AuthenticatesSuccessfully) {
    CustomerNode *cNode = (CustomerNode *)malloc(sizeof(CustomerNode));
    memset(&cNode->data, 0, sizeof(Customer));
    strcpy(cNode->data.customerId, "CUST1001");
    strcpy(cNode->data.username, "alice");
    strcpy(cNode->data.fullName, "Alice Wonderland");
    hashPassword("aliceSecret", NULL, PBKDF2_ITERATIONS, cNode->data.password, sizeof(cNode->data.password));
    cNode->next = NULL;
    customerHead = cNode;

    RedirectStdin input("alice\naliceSecret\n5\n"); /* Login then logout */
    CaptureStdout capture;
    customerLogin();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Welcome back, Alice Wonderland!"), std::string::npos);
}

TEST_F(CHSTestFixture, TC51_CustomerLogin_InvalidPassword_AuthenticationFails) {
    CustomerNode *cNode = (CustomerNode *)malloc(sizeof(CustomerNode));
    memset(&cNode->data, 0, sizeof(Customer));
    strcpy(cNode->data.customerId, "CUST1001");
    strcpy(cNode->data.username, "alice");
    hashPassword("aliceSecret", NULL, PBKDF2_ITERATIONS, cNode->data.password, sizeof(cNode->data.password));
    cNode->next = NULL;
    customerHead = cNode;

    RedirectStdin input("alice\nwrongPassword\n");
    CaptureStdout capture;
    customerLogin();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Authentication failed"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 14: CustomerDashboardTest (Function: customerDashboard)             */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC52_CustomerDashboard_MenuNavigationAndLogout) {
    RedirectStdin input("5\n"); /* Logout */
    CaptureStdout capture;
    EXPECT_NO_FATAL_FAILURE(customerDashboard("CUST1001", "Test User"));
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Logging out of customer session"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 15: ComplaintCreationTest (Function: customerRegisterComplaint)     */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC53_CustomerRegisterComplaint_ValidInput_GeneratesSequentialIdAndAssigns) {
    initSystem();
    RedirectStdin input("1\n2\nSystem crash on login\n");
    CaptureStdout capture;
    customerRegisterComplaint("CUST1001");

    ComplaintNode *comp = findComplaintById("CMP101");
    ASSERT_NE(comp, nullptr);
    EXPECT_STREQ(comp->data.customerId, "CUST1001");
    EXPECT_STREQ(comp->data.category, "Technical Support");
    EXPECT_STREQ(comp->data.priority, "Medium");
    EXPECT_STREQ(comp->data.status, "ASSIGNED");
    EXPECT_NE(comp->auditHead, nullptr);
}

TEST_F(CHSTestFixture, TC54_CustomerRegisterComplaint_EmptyDescription_RejectsRegistration) {
    initSystem();
    RedirectStdin input("1\n1\n\n");
    CaptureStdout capture;
    customerRegisterComplaint("CUST1001");

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Registration aborted"), std::string::npos);
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);
}

/* ========================================================================= */
/* SUITE 16: CustomerComplaintViewTest (Function: customerViewComplaints)    */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC55_CustomerViewComplaints_FiltersStrictlyByCustomerId) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    strcpy(c1->data.category, "Billing");
    c1->auditHead = NULL;

    ComplaintNode *c2 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c2->data, 0, sizeof(Complaint));
    strcpy(c2->data.complaintId, "CMP102");
    strcpy(c2->data.customerId, "CUST1002");
    c2->auditHead = NULL;

    c1->next = c2;
    c2->next = NULL;
    complaintHead = c1;

    CaptureStdout capture;
    customerViewComplaints("CUST1001");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CMP101"), std::string::npos);
    EXPECT_EQ(out.find("CMP102"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 17: CustomerComplaintTrackTest (Function: customerTrackComplaint)   */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC56_CustomerTrackComplaint_OwnComplaint_DisplaysTimeline) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    strcpy(c1->data.status, "IN_PROGRESS");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    RedirectStdin input("CMP101\n");
    CaptureStdout capture;
    customerTrackComplaint("CUST1001");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("COMPLAINT TRACKING: CMP101"), std::string::npos);
    EXPECT_NE(out.find("Active Investigation"), std::string::npos);
}

TEST_F(CHSTestFixture, TC57_CustomerTrackComplaint_OtherCustomerComplaint_AccessDenied) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1002");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    RedirectStdin input("CMP101\n");
    CaptureStdout capture;
    customerTrackComplaint("CUST1001");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Security violation"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 18: CustomerComplaintHistoryTest (Function: customerViewHistory)    */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC58_CustomerViewHistory_OwnComplaint_DisplaysAuditTrail) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;
    addAuditEntry(c1, "TEST_ACTION", "CUST1001", "Audit details");

    RedirectStdin input("CMP101\n");
    CaptureStdout capture;
    customerViewHistory("CUST1001");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("TEST_ACTION"), std::string::npos);
    EXPECT_NE(out.find("Audit details"), std::string::npos);
}

TEST_F(CHSTestFixture, TC59_CustomerViewHistory_OtherCustomerComplaint_AccessDenied) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1002");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    RedirectStdin input("CMP101\n");
    CaptureStdout capture;
    customerViewHistory("CUST1001");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Security violation"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 19: AgentMenuTest (Function: agentMenu)                             */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC60_AgentMenu_ValidLoginAndInactiveAgentCheck) {
    initSystem();
    agents[0].isActive = 0; /* Make AGT101 inactive */

    RedirectStdin input("1\nagent1\nagentpass1\n2\n");
    CaptureStdout capture;
    agentMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Access denied: Your agent account is currently set to Inactive"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 20: AgentDashboardTest (Function: agentDashboard)                   */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC61_AgentDashboard_WorkloadComputationAndLogout) {
    initSystem();
    RedirectStdin input("4\n"); /* Logout */
    CaptureStdout capture;
    agentDashboard(0);
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("AGENT DASHBOARD: Alice Smith"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 21: AgentOperationsTest (Functions: agentViewAssigned, agentUpdateComplaint) */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC62_AgentViewAssigned_DisplaysOnlyAgentComplaints) {
    initSystem();
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    strcpy(c1->data.category, "Technical");
    strcpy(c1->data.priority, "High");
    strcpy(c1->data.status, "ASSIGNED");
    strcpy(c1->data.assignedAgentId, "AGT101");
    strcpy(c1->data.timestamps.updated, "2026-10-30 10:00:00");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    CaptureStdout capture;
    agentViewAssigned("AGT101");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CMP101"), std::string::npos);
    EXPECT_NE(out.find("Total Assigned: 1"), std::string::npos);
}

TEST_F(CHSTestFixture, TC63_AgentUpdateComplaint_ValidStatusTransitionAndAudit) {
    initSystem();
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.assignedAgentId, "AGT101");
    strcpy(c1->data.status, "ASSIGNED");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    /* Select Option 1 (IN_PROGRESS), note: "Investigating" */
    RedirectStdin input("CMP101\n1\nInvestigating\n");
    CaptureStdout capture;
    agentUpdateComplaint("AGT101");

    EXPECT_STREQ(c1->data.status, "IN_PROGRESS");
    EXPECT_STREQ(c1->data.lastNote, "Investigating");
    ASSERT_NE(c1->auditHead, nullptr);
    EXPECT_STREQ(c1->auditHead->action, "IN_PROGRESS");
}

/* ========================================================================= */
/* SUITE 22: ManagerMenuTest (Function: managerMenu)                         */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC64_ManagerMenu_AuthenticationAndLogout) {
    initSystem();
    /* Option 1: Login (manager/manager123), then Option 7 (Logout), then Option 2 (Return) */
    RedirectStdin input("1\nmanager\nmanager123\n7\n2\n");
    CaptureStdout capture;
    managerMenu();
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Welcome, Operations Manager!"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 23: ManagerEscalatedComplaintsTest (Function: managerViewEscalatedComplaints) */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC65_ManagerViewEscalatedComplaints_OnlyEscalatedDisplayed) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    strcpy(c1->data.category, "Technical");
    strcpy(c1->data.priority, "Critical");
    strcpy(c1->data.status, "ESCALATED");
    strcpy(c1->data.assignedAgentId, "AGT102");
    strcpy(c1->data.timestamps.escalated, "2026-10-30 14:00:00");
    strcpy(c1->data.description, "Critical server outage");
    c1->auditHead = NULL;

    ComplaintNode *c2 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c2->data, 0, sizeof(Complaint));
    strcpy(c2->data.complaintId, "CMP102");
    strcpy(c2->data.status, "IN_PROGRESS");
    c2->auditHead = NULL;

    c1->next = c2;
    c2->next = NULL;
    complaintHead = c1;

    CaptureStdout capture;
    managerViewEscalatedComplaints();
    std::string out = capture.getOutput();

    EXPECT_NE(out.find("CMP101"), std::string::npos);
    EXPECT_NE(out.find("Critical server outage"), std::string::npos);
    EXPECT_NE(out.find("AGT102"), std::string::npos);
    EXPECT_NE(out.find("Total Escalated Complaints: 1"), std::string::npos);
    EXPECT_EQ(out.find("CMP102"), std::string::npos);
}

TEST_F(CHSTestFixture, TC66_ManagerViewEscalatedComplaints_NoEscalatedComplaints_DisplaysNotice) {
    CaptureStdout capture;
    managerViewEscalatedComplaints();
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("No escalated complaints found."), std::string::npos);
}

TEST_F(CHSTestFixture, TC67_ManagerViewEscalatedComplaints_UnassignedAgent_HandlesSafely) {
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP103");
    strcpy(c1->data.customerId, "CUST1003");
    strcpy(c1->data.status, "ESCALATED");
    c1->data.assignedAgentId[0] = '\0'; /* Unassigned */
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    CaptureStdout capture;
    managerViewEscalatedComplaints();
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CMP103"), std::string::npos);
    EXPECT_NE(out.find("Unassigned"), std::string::npos);
}

/* ========================================================================= */
/* SUITE 24: ManagerAdministrativeOperationsTest                             */
/* (Functions: managerViewAllComplaints, managerAssignComplaint,             */
/*             managerUpdateComplaint, managerAgentManagement)               */
/* ========================================================================= */

TEST_F(CHSTestFixture, TC68_ManagerViewAllComplaints_MetricsAndListing) {
    initSystem();
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    strcpy(c1->data.category, "Technical");
    strcpy(c1->data.priority, "High");
    strcpy(c1->data.status, "PENDING");
    strcpy(c1->data.assignedAgentId, "UNASSIGNED");
    strcpy(c1->data.timestamps.registered, "2026-10-30 10:00:00");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    CaptureStdout capture;
    managerViewAllComplaints();
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("SYSTEM METRICS & DASHBOARD"), std::string::npos);
    EXPECT_NE(out.find("CMP101"), std::string::npos);
}

TEST_F(CHSTestFixture, TC69_ManagerAssignAndUpdateComplaint_TransitionsAndAudit) {
    initSystem();
    ComplaintNode *c1 = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    memset(&c1->data, 0, sizeof(Complaint));
    strcpy(c1->data.complaintId, "CMP101");
    strcpy(c1->data.customerId, "CUST1001");
    strcpy(c1->data.status, "PENDING");
    strcpy(c1->data.assignedAgentId, "UNASSIGNED");
    c1->auditHead = NULL;
    c1->next = NULL;
    complaintHead = c1;

    /* Assign to AGT101 */
    {
        RedirectStdin input("CMP101\nAGT101\n");
        CaptureStdout capture;
        managerAssignComplaint();
        EXPECT_STREQ(c1->data.assignedAgentId, "AGT101");
        EXPECT_STREQ(c1->data.status, "ASSIGNED");
    }

    /* Update status to RESOLVED (Option 2) */
    {
        RedirectStdin input("CMP101\n2\nIssue resolved by manager\n");
        CaptureStdout capture;
        managerUpdateComplaint();
        EXPECT_STREQ(c1->data.status, "RESOLVED");
        ASSERT_NE(c1->auditHead, nullptr);
    }
}

TEST_F(CHSTestFixture, TC70_ManagerAgentManagement_ToggleAgentStatus) {
    initSystem();
    EXPECT_EQ(agents[0].isActive, 1);

    /* Toggle AGT101, then option 2 (Return) */
    RedirectStdin input("1\nAGT101\n2\n");
    CaptureStdout capture;
    managerAgentManagement();

    EXPECT_EQ(agents[0].isActive, 0);
}

