#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================================================"
echo " Building Google Test Suite for Complaint Handling System..."
echo "========================================================================"

mkdir -p build
cd build

if command -v cmake >/dev/null 2>&1; then
    cmake .. -DCMAKE_BUILD_TYPE=Debug >/dev/null
    make -j$(nproc)
else
    g++ -std=c++17 -O0 -g3 -DUNIT_TESTING=1 -I../../include ../test_chs.cpp ../../src/main.c \
        -lgtest -lgtest_main -lssl -lcrypto -pthread -o chs_tests
fi

echo "========================================================================"
echo " Executing Google Test Suite..."
echo "========================================================================"

./chs_tests --gtest_color=yes
TEST_STATUS=$?

if [ $TEST_STATUS -eq 0 ]; then
    echo "========================================================================"
    echo " [SUCCESS] 100% Google Test Pass Rate Achieved."
    echo "========================================================================"
else
    echo "========================================================================"
    echo " [FAILURE] One or more Google Tests failed with status: $TEST_STATUS"
    echo "========================================================================"
    exit $TEST_STATUS
fi
