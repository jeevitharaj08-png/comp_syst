#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "========================================================================"
echo " Preparing Helgrind Workflow in Sandbox..."
echo "========================================================================"

TMP_HELG_DIR=$(mktemp -d /tmp/chs_helgrind_XXXXXX)
mkdir -p "$TMP_HELG_DIR/data"
cp -r "$ROOT_DIR/data/"* "$TMP_HELG_DIR/data/" 2>/dev/null || true

WORKFLOW_INPUT=$(cat << 'EOF'
1
1
David Miller
dmiller
MillerSecure99
david@test.com
2
dmiller
MillerSecure99
1
1
3
Network drop issues
2
3
CMP101
4
CMP101
5
3
2
1
agent1
agentpass1
1
2
CMP101
3
Escalated to senior management
3
CMP101
4
2
3
1
manager
manager123
1
2
3
CMP101
AGT102
4
CMP101
1
Manager investigation in progress
5
1
AGT104
2
6
7
2
4
EOF
)

echo "========================================================================"
echo " Executing Valgrind Helgrind on Production Binary..."
echo "========================================================================"

cd "$TMP_HELG_DIR"
echo "$WORKFLOW_INPUT" | valgrind --tool=helgrind \
    --error-exitcode=1 \
    --log-file="$ROOT_DIR/reports/helgrind_workflow.log" \
    "$ROOT_DIR/build/complaint_app"

HELG_STATUS=$?
rm -rf "$TMP_HELG_DIR"

echo "========================================================================"
echo " Valgrind Helgrind Output Summary:"
cat "$ROOT_DIR/reports/helgrind_workflow.log" | tail -n 25
echo "========================================================================"

if [ $HELG_STATUS -eq 0 ]; then
    echo "[SUCCESS] Zero Helgrind threading errors, zero data races detected."
    exit 0
else
    echo "[FAILURE] Helgrind detected threading errors (exit code: $HELG_STATUS)"
    exit $HELG_STATUS
fi
