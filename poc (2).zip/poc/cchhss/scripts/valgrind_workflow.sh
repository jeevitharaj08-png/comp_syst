#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "========================================================================"
echo " Preparing Valgrind Memcheck Workflow in Sandbox..."
echo "========================================================================"

TMP_VAL_DIR=$(mktemp -d /tmp/chs_valgrind_XXXXXX)
mkdir -p "$TMP_VAL_DIR/data"
cp -r "$ROOT_DIR/data/"* "$TMP_VAL_DIR/data/" 2>/dev/null || true

# Construct comprehensive automated workflow input stream
WORKFLOW_INPUT=$(cat << 'EOF'
1
1
David Miller
dmiller
MillerSecure99
david@test.com
2
dmiller
MillerSecure99
1
1
3
Network connection drops frequently
2
3
CMP101
4
CMP101
5
3
2
1
agent1
agentpass1
1
2
CMP101
3
Escalated to L2 network team
3
CMP101
4
2
3
1
manager
manager123
1
2
3
CMP101
AGT102
4
CMP101
1
Manager confirmed investigation
5
1
AGT103
2
6
7
2
4
EOF
)

echo "========================================================================"
echo " Executing Valgrind Memcheck on Production Binary..."
echo "========================================================================"

cd "$TMP_VAL_DIR"
echo "$WORKFLOW_INPUT" | valgrind --leak-check=full \
    --show-leak-kinds=all \
    --track-origins=yes \
    --error-exitcode=1 \
    --log-file="$ROOT_DIR/reports/valgrind_workflow.log" \
    "$ROOT_DIR/build/complaint_app"

VAL_STATUS=$?
rm -rf "$TMP_VAL_DIR"

echo "========================================================================"
echo " Valgrind Memcheck Output Summary:"
cat "$ROOT_DIR/reports/valgrind_workflow.log" | tail -n 25
echo "========================================================================"

if [ $VAL_STATUS -eq 0 ]; then
    echo "[SUCCESS] Zero Valgrind Memcheck errors, zero leaks detected."
    exit 0
else
    echo "[FAILURE] Valgrind detected memory errors (exit code: $VAL_STATUS)"
    exit $VAL_STATUS
fi
