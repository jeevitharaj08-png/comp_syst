# Manager Portal Escalated Complaints Feature Report

**Project:** Complaint Handling System (CHS)  
**Target Component:** Manager Portal (`managerDashboard`, `managerViewEscalatedComplaints`)  
**Implementation Source:** [`src/main.c:1601`](file:///c:/Users/likhi/OneDrive/Desktop/poc/src/main.c#L1601)  
**Header Declaration:** [`include/complaint_system.h:130`](file:///c:/Users/likhi/OneDrive/Desktop/poc/include/complaint_system.h#L130)  
**Assessment Date:** October 30, 2026  

---

## 1. Feature Background & Requirements

Original system documentation referenced an option to inspect escalated complaints within the management tier, but this feature was missing from the actual manager command-line interface.

### Requirements:
1. Provide a working, dedicated "View Escalated Complaints" menu option in the Manager Dashboard.
2. Filter the global complaint linked list strictly for complaints in the `ESCALATED` status.
3. Display essential operational details:
   - Complaint ID
   - Customer ID
   - Category
   - Priority
   - Assigned Agent (or "UNASSIGNED" if unassigned)
   - Registration Timestamp
   - Escalation Timestamp (or Last Updated Timestamp)
4. Gracefully handle zero escalated complaints with an informative notification.
5. Guarantee complete read-only integrity: viewing escalated tickets must never modify ticket statuses, update timestamps, or append audit records.
6. Seamlessly integrate alongside existing management features (View All, Assign/Reassign, Update/Close, Agent Management, Audit Log).

---

## 2. Technical Implementation Architecture

### 2.1 Function Design
The feature is implemented in `src/main.c` as:
```c
void managerViewEscalatedComplaints(void)
```

### 2.2 Operational Logic & Thread Safety:
1. **Thread Synchronization:** The function acquires `pthread_mutex_lock(&dataMutex)` before reading `complaintHead` to ensure consistent data views and prevent race conditions with concurrent operations or the background monitoring thread.
2. **Strict Filtering:** Traverses `complaintHead`, evaluating `cNode->complaint.status == ESCALATED`. Non-escalated complaints (`NEW`, `ASSIGNED`, `IN_PROGRESS`, `RESOLVED`, `CLOSED`) are completely excluded.
3. **Escalation Timestamp Resolution:** Inspects the nested `auditHead` linked list for an action labeled `"ESCALATED"`. If found, its exact timestamp is rendered; otherwise, it falls back cleanly to `cNode->complaint.timestamps.updated` or `registered`.
4. **Defensive Formatting:** If `assignedAgent` is empty, it prints `"UNASSIGNED"` rather than attempting invalid lookups.
5. **No State Mutation:** Pointers are strictly dereferenced for display; zero fields are written.
6. **Mutex Release:** Unlocks `pthread_mutex_unlock(&dataMutex)` prior to returning to the caller.

### 2.3 User Interface Integration
The option is integrated as **Option 2** in `managerDashboard()`:
```text
----------------------------------------
           MANAGER DASHBOARD
----------------------------------------
1. View all complaints & system dashboard
2. View Escalated Complaints
3. Assign / Reassign complaint to agent
4. Update complaint status / close / escalate
5. Agent management (workload & status)
6. View complete system audit log
7. Logout
```

---

## 3. UI Presentation & Formatting

### 3.1 Scenario A: Active Escalated Complaints Present
```text
========================================================================================================================
                                             ESCALATED COMPLAINTS REPORT
========================================================================================================================
Complaint ID | Customer ID | Category             | Priority | Assigned Agent | Registered Date     | Escalated Date      
------------------------------------------------------------------------------------------------------------------------
CMP101       | CUST1001    | Technical Support    | High     | AGT101         | 2026-10-30 16:18:32 | 2026-10-30 16:18:32 
CMP104       | CUST1003    | Billing and Account  | Critical | AGT102         | 2026-10-30 16:22:10 | 2026-10-30 16:25:40 
------------------------------------------------------------------------------------------------------------------------
Total Escalated Complaints Requiring Management Attention: 2
========================================================================================================================
```

### 3.2 Scenario B: Zero Escalated Complaints
```text
========================================================================================================================
                                             ESCALATED COMPLAINTS REPORT
========================================================================================================================
[INFO] No complaints are currently in ESCALATED status. All tickets are operating normally.
========================================================================================================================
```

---

## 4. Verification & Testing

The feature was tested under normal, edge, and negative scenarios in both automated unit tests and full-system workflows:

| Test Scenario | Verification Suite | Expected Behavior | Actual Result |
| :--- | :---: | :--- | :---: |
| Only Escalated Displayed | GTest `TC65` | Filters out NEW, ASSIGNED, and RESOLVED tickets; renders only ESCALATED | **PASS** |
| Zero Escalated Tickets | GTest `TC66` | Displays clean informational notice without table header errors | **PASS** |
| Unassigned Agent Handling | GTest `TC67` | Displays `"UNASSIGNED"` cleanly without null pointer exceptions | **PASS** |
| Full Ticket Lifecycle | GTest `TC69` | Escalating ticket adds it to view; resolving ticket removes it | **PASS** |
| Read-Only Invariance | Full Workflow | State before and after viewing identical (0 audit entries added) | **PASS** |
| Multithreaded Access | Helgrind | Zero data races under concurrent thread execution | **PASS** |
| Memory Cleanliness | Valgrind | Zero heap allocations leaked during display traversal | **PASS** |
