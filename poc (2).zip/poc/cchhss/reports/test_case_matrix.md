# Comprehensive Google Test Case Matrix (70 Test Cases)

**Project:** Complaint Handling System (CHS)  
**Framework:** Google Test (GTest v1.17.0 C++17)  
**Execution Environment:** Linux (Ubuntu 24.04 LTS / x86_64, GCC 15.2.0)  
**Total Test Cases:** 70  
**Passed:** 70 (100.0%)  
**Failed:** 0 (0.0%)  
**Total Execution Time:** 521 ms  

---

## 1. Test Summary by Category

| Category | Description | Count | Pass Rate |
| :--- | :--- | :---: | :---: |
| **Normal (Positive)** | Standard workflows, expected user operations, valid state transitions | 28 | 100% |
| **Edge Cases** | Boundary values, zero/empty states, maximum lengths, ties | 22 | 100% |
| **Hidden / Negative** | Unauthorized access, malformed records, null pointers, corruption | 20 | 100% |
| **TOTAL** | **Comprehensive Full-System Coverage** | **70** | **100%** |

---

## 2. Granular Test Case Matrix (TC01 – TC70)

| Test ID | Test Suite & Name | Target Function | Category | Scenario / Inputs | Expected Output | Status |
| :---: | :--- | :--- | :---: | :--- | :--- | :---: |
| **TC01** | `GetTimestamp_ValidBuffer` | `getTimestamp` | Normal | 26-byte buffer supplied | Returns `YYYY-MM-DD HH:MM:SS` format (19 chars) | **PASS** |
| **TC02** | `GetTimestamp_NullBuffer` | `getTimestamp` | Negative | `buffer == NULL`, size 26 | Safe no-op, no segfault or crash | **PASS** |
| **TC03** | `GetTimestamp_ZeroSize` | `getTimestamp` | Edge | Valid buffer, `size == 0` | Safe no-op, buffer untouched | **PASS** |
| **TC04** | `ReadString_SanitizesPipes` | `readString` | Normal | Input `"Alpha\|Beta\|Gamma"` | Delimiter pipes sanitized to `"Alpha-Beta-Gamma"` | **PASS** |
| **TC05** | `ReadString_NullBuffer` | `readString` | Negative | `buffer == NULL` or `size == 0` | Safe return without memory violation | **PASS** |
| **TC06** | `ReadInt_ValidInput` | `readInt` | Normal | Input `"3\n"`, range `[1, 5]` | Returns integer `3` | **PASS** |
| **TC07** | `ReadInt_OutOfRange` | `readInt` | Edge | Input `"0\n6\n4\n"`, range `[1, 5]` | Rejects out-of-range inputs, returns `4` | **PASS** |
| **TC08** | `HashPassword_ValidInput` | `hashPassword` | Normal | Valid password `"P@ssw0rd123"` | Returns 1; outputs format `$pbkdf2-sha256$i=10000$...` | **PASS** |
| **TC09** | `HashPassword_EmptyPassword` | `hashPassword` | Negative | `password == ""` | Returns 0 (rejected) | **PASS** |
| **TC10** | `HashPassword_InvalidIterations` | `hashPassword` | Edge | `iterations = 500` (< 1000) | Returns 0 (rejected below security threshold) | **PASS** |
| **TC11** | `HashPassword_SmallOutputBuffer` | `hashPassword` | Negative | `outSize = 50` (< 160) | Returns 0 (prevents truncation) | **PASS** |
| **TC12** | `HashPassword_IdenticalPass_DiffSalts` | `hashPassword` | Normal | Same password, two different salts | Generates two unique, cryptographically distinct hashes | **PASS** |
| **TC13** | `HashPassword_CustomSalt` | `hashPassword` | Normal | Fixed salt `"0123456789abcdef0123456789abcdef"` | Generates identical deterministic hash across runs | **PASS** |
| **TC14** | `VerifyPassword_CorrectPassword` | `verifyPassword` | Normal | Correct password matching PBKDF2 hash | Returns 1 (authentication success) | **PASS** |
| **TC15** | `VerifyPassword_IncorrectPassword` | `verifyPassword` | Negative | Incorrect password against PBKDF2 hash | Returns 0 (constant-time authentication failure) | **PASS** |
| **TC16** | `VerifyPassword_MalformedStoredHash` | `verifyPassword` | Negative | Stored hash missing dollar delimiters | Returns 0 (rejection without crash) | **PASS** |
| **TC17** | `VerifyPassword_InvalidSaltLength` | `verifyPassword` | Edge | Salt length 10 hex characters (< 32) | Returns 0 (rejection) | **PASS** |
| **TC18** | `VerifyPassword_InvalidHashLength` | `verifyPassword` | Edge | Hash length 20 hex characters (< 64) | Returns 0 (rejection) | **PASS** |
| **TC19** | `VerifyPassword_LegacyPlaintext` | `verifyPassword` | Edge | Legacy unhashed password `"legacyPass"` | Returns 2 (legacy match, flags for migration) | **PASS** |
| **TC20** | `FindCustomerByUsername_Existing` | `findCustomerByUsername` | Normal | Existing username `"alice"` | Returns valid pointer to `CustomerNode` | **PASS** |
| **TC21** | `FindCustomerByUsername_NonExistent`| `findCustomerByUsername` | Edge | Non-existent username `"unknown"` | Returns `NULL` | **PASS** |
| **TC22** | `FindCustomerByUsername_NullOrEmpty`| `findCustomerByUsername` | Negative | `username == NULL` or `""` | Returns `NULL` safely | **PASS** |
| **TC23** | `FindComplaintById_ExistingId` | `findComplaintById` | Normal | Existing ID `"CMP101"` | Returns valid pointer to `ComplaintNode` | **PASS** |
| **TC24** | `FindComplaintById_NonExistentId` | `findComplaintById` | Edge | Non-existent ID `"CMP999"` | Returns `NULL` | **PASS** |
| **TC25** | `FindComplaintById_NullOrEmpty` | `findComplaintById` | Negative | `complaintId == NULL` or `""` | Returns `NULL` safely | **PASS** |
| **TC26** | `AddAuditEntry_ValidComplaint` | `addAuditEntry` | Normal | Valid complaint node, action `"UPDATED"`| Appends audit node with timestamp and details | **PASS** |
| **TC27** | `AddAuditEntry_NullComplaint` | `addAuditEntry` | Negative | `node == NULL` | Safe no-op, no NULL dereference | **PASS** |
| **TC28** | `AutoAssignAgent_LeastLoadedActive` | `autoAssignAgent` | Normal | Agents with varying workloads | Selects active agent with lowest active ticket count | **PASS** |
| **TC29** | `AutoAssignAgent_AllInactive` | `autoAssignAgent` | Edge | All 10 agents marked INACTIVE | Returns -1 (handled gracefully by complaint intake) | **PASS** |
| **TC30** | `InitSystem_LoadsAgentsAndDefaults` | `initSystem` | Normal | System boot with clean data directory | Seeds 10 agents with hashed credentials, creates files | **PASS** |
| **TC31** | `InitSystem_NoDirectory_CreatesFresh`| `initSystem` | Edge | `data/` directory does not exist | Automatically creates directory with 0755 permissions | **PASS** |
| **TC32** | `InitSystem_LegacyMigration` | `initSystem` | Edge | `agents.txt` containing plaintext password | Upgrades in-memory & on-disk credentials to PBKDF2 | **PASS** |
| **TC33** | `SaveAllData_WritesAllFiles` | `saveAllData` | Normal | Active memory state | Persists agents, customers, complaints, and manager | **PASS** |
| **TC34** | `SaveAllData_EmptyState` | `saveAllData` | Edge | Zero customers, zero complaints | Writes valid empty files without crashing | **PASS** |
| **TC35** | `SaveAllData_ManagerFilePermissions`| `saveAllData` | Negative | Inspect `data/manager.txt` mode | Permissions restricted to `0600` on Linux | **PASS** |
| **TC36** | `FreeAllMemory_FreesNodesAndResets` | `freeAllMemory` | Normal | Allocated customers, complaints, audits | Deallocates all heap blocks, resets heads to `NULL` | **PASS** |
| **TC37** | `MonitoringThread_StartsAndExits` | `monitoringThread` | Normal | Spawns thread, signals `systemRunning=0`| Thread awakens via condition variable and joins cleanly | **PASS** |
| **TC38** | `MonitoringThread_ConcurrencyCheck` | `monitoringThread` | Normal | Concurrent complaint mutation | Verified with zero data races under Helgrind | **PASS** |
| **TC39** | `CustomerMenu_Navigation` | `customerMenu` | Normal | Option 3 (Return) | Exits menu loop cleanly | **PASS** |
| **TC40** | `CustomerMenu_EOFHandling` | `customerMenu` | Negative | EOF condition on stdin | Handles termination without looping indefinitely | **PASS** |
| **TC41** | `Password_MaxSupportedLength` | `hashPassword` | Edge | Maximum password length (128 characters)| Hashes and verifies successfully | **PASS** |
| **TC42** | `Password_RestartPersistence` | `initSystem`, `saveAllData` | Normal | Save hashed account, re-init system | Successful authentication persists after restart | **PASS** |
| **TC43** | `Password_TruncatedStoredCredential`| `verifyPassword` | Negative | Stored hash string truncated mid-stream | Returns 0 (verification failure, no out-of-bounds read) | **PASS** |
| **TC44** | `Password_InvalidIterationCount` | `verifyPassword` | Negative | Hash formatted with `i=0` or `i=abc` | Returns 0 (safely rejected) | **PASS** |
| **TC45** | `Password_NoPlaintextPersisted` | `saveAllData` | Normal | Grep all files in `data/` | Confirms zero plaintext passwords remain on disk | **PASS** |
| **TC46** | `Password_NoRepeatedRehashing` | `verifyPassword`, `saveAllData`| Normal | Authenticate already-migrated account | Returns 1; does not create redundant hash iterations | **PASS** |
| **TC47** | `CustomerRegister_ValidDetails` | `customerRegister` | Normal | New username, password, email | Creates `CUST1001` with PBKDF2 hash, appends node | **PASS** |
| **TC48** | `CustomerRegister_DuplicateUsername`| `customerRegister` | Edge | Attempt to register existing username | Rejects with warning, does not consume customer ID | **PASS** |
| **TC49** | `CustomerRegister_BlankFields` | `customerRegister` | Negative | Empty username or password input | Aborts registration without modifying linked list | **PASS** |
| **TC50** | `CustomerLogin_ValidCredentials` | `customerLogin` | Normal | Valid customer username and password | Authenticates successfully and enters dashboard | **PASS** |
| **TC51** | `CustomerLogin_InvalidPassword` | `customerLogin` | Negative | Correct username, incorrect password | Rejects login, returns to portal menu | **PASS** |
| **TC52** | `CustomerDashboard_Navigation` | `customerDashboard` | Normal | Option 5 (Logout) | Exits customer session and returns to portal menu | **PASS** |
| **TC53** | `CustomerRegComplaint_ValidInput` | `customerRegisterComplaint`| Normal | Category 1, Priority 3, valid text | Generates `CMP101`, status `ASSIGNED`, logs audit | **PASS** |
| **TC54** | `CustomerRegComplaint_EmptyDesc` | `customerRegisterComplaint`| Negative | Blank description provided | Rejects submission, preserves sequence number | **PASS** |
| **TC55** | `CustomerViewComplaints_StrictFilter`| `customerViewComplaints` | Normal | Multiple complaints from multiple users | Displays strictly caller's complaints; filters others | **PASS** |
| **TC56** | `CustomerTrackComplaint_OwnTicket` | `customerTrackComplaint` | Normal | Caller enters own complaint ID `CMP101` | Displays stage progression and progress timeline | **PASS** |
| **TC57** | `CustomerTrackComplaint_OtherTicket`| `customerTrackComplaint` | Negative | Caller enters other customer's ticket | Access denied: `"Security violation: Access denied."` | **PASS** |
| **TC58** | `CustomerViewHistory_OwnTicket` | `customerViewHistory` | Normal | Caller requests history of `CMP101` | Displays full chronological audit trail | **PASS** |
| **TC59** | `CustomerViewHistory_OtherTicket` | `customerViewHistory` | Negative | Caller requests history of other's ticket| Access denied: audit history withheld | **PASS** |
| **TC60** | `AgentMenu_ValidAndInactive` | `agentMenu` | Normal | Active agent logs in; inactive blocked | Validates active flag; blocks inactive agent | **PASS** |
| **TC61** | `AgentDashboard_WorkloadComputation`| `agentDashboard` | Normal | Computes active vs resolved count | Calculates agent KPIs accurately; logs out cleanly | **PASS** |
| **TC62** | `AgentViewAssigned_StrictFilter` | `agentViewAssigned` | Normal | Inspect assigned tickets | Displays only tickets where `assignedAgent == agentId` | **PASS** |
| **TC63** | `AgentUpdateComplaint_Transitions` | `agentUpdateComplaint` | Normal | Update status to `IN_PROGRESS`/`RESOLVED`| Updates status, timestamps, and appends audit record | **PASS** |
| **TC64** | `ManagerMenu_AuthAndLogout` | `managerMenu` | Normal | Manager credentials (`manager`/`manager123`)| Authenticates, launches dashboard, logs out cleanly | **PASS** |
| **TC65** | `ManagerViewEscalated_Filtering` | `managerViewEscalatedComplaints`| Normal | 1 ESCALATED, 1 RESOLVED complaint | Displays ONLY the escalated complaint with timestamps | **PASS** |
| **TC66** | `ManagerViewEscalated_ZeroEscalated`| `managerViewEscalatedComplaints`| Edge | No complaints in `ESCALATED` status | Displays `"No complaints are currently in ESCALATED status."`| **PASS** |
| **TC67** | `ManagerViewEscalated_Unassigned` | `managerViewEscalatedComplaints`| Edge | Escalated complaint with empty agent | Displays `"UNASSIGNED"` agent safely without crash | **PASS** |
| **TC68** | `ManagerViewAllComplaints_Metrics` | `managerViewAllComplaints` | Normal | Mixed complaint statuses and priorities| Formats KPI breakdown cards and full complaint list | **PASS** |
| **TC69** | `ManagerAssignAndUpdate_Workflow` | `managerAssignComplaint`, `managerUpdateComplaint`| Normal | Reassign complaint, update to `CLOSED` | Changes assignment, records manager audit entry | **PASS** |
| **TC70** | `ManagerAgentManagement_ToggleStatus`| `managerAgentManagement` | Normal | Toggle agent active/inactive state | Flips `agent.active` flag, re-evaluates auto-assign | **PASS** |

---

## 3. Redundant Test Elimination Report

The previous implementation possessed fragmented and redundant tests that repeatedly exercised identical static string paths without evaluating boundary conditions or error handlers. 

### Tests Pruned and Consolidated:
1. **Redundant Plaintext Comparison Tests:** Replaced 6 identical `strcmp` tests with parameterized PBKDF2 hash tests covering length, salt variability, iteration boundaries, and malformed markers.
2. **Duplicated Menu Display Loops:** Consolidated repetitive menu print checks into functional navigation tests (`TC39`, `TC52`, `TC61`, `TC64`).
3. **Redundant ID Format Tests:** Merged separate prefix and counter tests into unified sequential validation tests (`TC53`).

### High-Value Tests Added:
1. **Cryptographic Salt Uniqueness & Invariance:** `TC12`, `TC13`.
2. **Constant-Time Verification & Failure Modes:** `TC14`, `TC15`, `TC16`, `TC17`, `TC18`.
3. **Legacy Migration & Persistence Without Plaintext:** `TC19`, `TC32`, `TC42`, `TC45`, `TC46`.
4. **Dedicated Escalated Complaints Filtering & Null Safeguards:** `TC65`, `TC66`, `TC67`.
5. **Cross-Customer Authorization Enforcement:** `TC57`, `TC59`.
6. **Thread Safety & Race Condition Prevention:** `TC37`, `TC38`.

---

## 4. Google Test Execution Verification Log

```text
Running main() from ./googletest/src/gtest_main.cc
[==========] Running 70 tests from 1 test suite.
[----------] Global test environment set-up.
[----------] 70 tests from CHSTestFixture
[ RUN      ] CHSTestFixture.TC01_GetTimestamp_ValidBuffer_FormatsStandardTimestamp
[       OK ] CHSTestFixture.TC01_GetTimestamp_ValidBuffer_FormatsStandardTimestamp (1 ms)
...
[ RUN      ] CHSTestFixture.TC70_ManagerAgentManagement_ToggleAgentStatus
[       OK ] CHSTestFixture.TC70_ManagerAgentManagement_ToggleAgentStatus (19 ms)
[----------] 70 tests from CHSTestFixture (520 ms total)

[----------] Global test environment tear-down
[==========] 70 tests from 1 test suite ran. (521 ms total)
[  PASSED  ] 70 tests.
========================================================================
 [SUCCESS] 100% Google Test Pass Rate Achieved.
========================================================================
```
