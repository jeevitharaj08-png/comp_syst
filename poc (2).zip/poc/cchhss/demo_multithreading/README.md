# Multithreading Demonstration & Synchronization Analysis

This standalone demonstration illustrates POSIX multithreading with thread-safe synchronization using mutexes.

## Architecture
- **Concurrency Model**: 4 concurrent POSIX worker threads (`pthread_create`).
- **Shared Resource**: A shared 64-bit integer counter.
- **Mutual Exclusion**: `pthread_mutex_t counterMutex` guarding each critical section.
- **Thread Lifecycle**: Main thread waits for completion using `pthread_join` and cleans up with `pthread_mutex_destroy`.

## Verification with Helgrind
Compile and run with Valgrind Helgrind:
```bash
make demo-threads
make helgrind
```
Helgrind verifies:
- 0 data races.
- 0 lock order violations.
- 0 mutex destruction errors.
