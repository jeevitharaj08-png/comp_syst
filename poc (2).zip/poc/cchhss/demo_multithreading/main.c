#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_WORKER_THREADS 4
#define INCREMENTS_PER_THREAD 10000

static long sharedCounter = 0;
static pthread_mutex_t counterMutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    int threadId;
    int increments;
} ThreadArgs;

void* workerFunction(void *arg) {
    ThreadArgs *args = (ThreadArgs *)arg;
    for (int i = 0; i < args->increments; ++i) {
        pthread_mutex_lock(&counterMutex);
        sharedCounter++;
        pthread_mutex_unlock(&counterMutex);
    }
    return NULL;
}

int main(void) {
    pthread_t threads[NUM_WORKER_THREADS];
    ThreadArgs args[NUM_WORKER_THREADS];

    (void)printf("=====================================================\n");
    (void)printf(" POSIX Multithreading Demonstration (Mutex Hardened)\n");
    (void)printf("=====================================================\n");
    (void)printf("Starting %d worker threads, %d increments each...\n",
                 NUM_WORKER_THREADS, INCREMENTS_PER_THREAD);

    for (int i = 0; i < NUM_WORKER_THREADS; ++i) {
        args[i].threadId = i + 1;
        args[i].increments = INCREMENTS_PER_THREAD;
        if (pthread_create(&threads[i], NULL, workerFunction, &args[i]) != 0) {
            (void)fprintf(stderr, "Error creating worker thread %d\n", i + 1);
            return 1;
        }
    }

    for (int i = 0; i < NUM_WORKER_THREADS; ++i) {
        (void)pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&counterMutex);

    long expected = (long)NUM_WORKER_THREADS * (long)INCREMENTS_PER_THREAD;
    (void)printf("All threads joined successfully.\n");
    (void)printf("Expected final counter: %ld\n", expected);
    (void)printf("Actual final counter:   %ld\n", sharedCounter);

    if (sharedCounter == expected) {
        (void)printf("[SUCCESS] Thread synchronization verified with zero data races.\n");
        return 0;
    } else {
        (void)fprintf(stderr, "[FAILURE] Data race detected in counter increment!\n");
        return 1;
    }
}
