# Complaint Handling System in C11 (Hardened & Upgraded)

A robust, modular, and cryptographically secure console-based Complaint Handling System built using standard **C11**, **OpenSSL**, **POSIX Threads**, **GCC**, **nested structures**, **arrays**, **singly linked lists**, and **persistent file handling**.

---

## 1. Compliance Matrix

| Constraint | Requirement | Status | Implementation Details |
| :--- | :--- | :---: | :--- |
| **Technology Stack** | Standard C11, GCC, OpenSSL EVP, POSIX Threads | **PASS** | Compiled with `gcc -std=c11 -Wall -Wextra -Wpedantic -pthread -lssl -lcrypto`. |
| **Password Security** | Salted PBKDF2-HMAC-SHA256 for all accounts | **PASS** | OpenSSL `PKCS5_PBKDF2_HMAC`, 10,000 iterations, 16-byte random salt (`RAND_bytes`), constant-time `CRYPTO_memcmp`. Zero plaintext passwords stored. |
| **Legacy Migration** | Transparent upgrade from legacy plaintext files | **PASS** | Auto-detects legacy plaintext on load/login, derives fresh PBKDF2 hash, rewrites storage files. Restricts `data/manager.txt` to `0600`. |
| **Manager Portal** | "View Escalated Complaints" Option | **PASS** | Dedicated Option 2 in Manager Portal; filters `ESCALATED` complaints, shows key details, zero state mutations, notice if none. |
| **Main Menu Options** | Exactly 4 options: Customer, Agent, Manager, Exit | **PASS** | Exact prompt format matched with safe input validation and clean shutdown. |
| **Function Count** | Application-defined functions in `src/main.c` | **PASS** | **Exactly 33 application-defined functions** (documented in [`reports/function_inventory.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/function_inventory.md)). |
| **Complaint Sequence** | Starts strictly at `CMP101`, followed by `CMP102`, etc. | **PASS** | Verified; sequence persists across application restarts. |
| **Automated Testing** | Google Test suite (60–70 tests) | **PASS** | **70 / 70 tests passed (100% pass rate)** in `gtests/test_chs.cpp`. |
| **Code Coverage** | GCC `gcov` & `gcovr` code coverage | **PASS** | **75.0% line coverage** (840/1120 lines), **77.58% branch coverage**, **100% function coverage**. |
| **Memory Safety** | Valgrind Memcheck verification | **PASS** | **0 errors from 0 contexts, 0 bytes definitely/indirectly lost** across full end-to-end multi-role lifecycle. |
| **Concurrency Safety**| Valgrind Helgrind thread safety verification | **PASS** | **0 errors from 0 contexts, 0 data races** on production binary and standalone demo. |

---

## 2. Main Menu & Manager Dashboard

### Main Menu
```text
========================================
       COMPLAINT HANDLING SYSTEM
========================================

1. Customer
2. Agent
3. Manager
4. Exit

Enter your choice: 
```

### Upgraded Manager Dashboard (7 Options)
```text
----------------------------------------
           MANAGER DASHBOARD
----------------------------------------
1. View all complaints & system dashboard
2. View Escalated Complaints
3. Assign / Reassign complaint to agent
4. Update complaint status / close / escalate
5. Agent management (workload & status)
6. View complete system audit log
7. Logout

Enter your choice: 
```

---

## 3. Predefined Credentials (Stored as PBKDF2 Hashes)

*Note: Passwords below are initial/default values for demonstration and evaluation. All passwords are automatically hashed with PBKDF2-HMAC-SHA256 upon system startup and persisted in `data/` in modular format `$pbkdf2-sha256$i=10000$<salt>$<hash>`.*

### Manager Account
- **Username:** `manager`
- **Default Password:** `manager123`
- **Name:** Operations Manager
- **Credential Storage:** `data/manager.txt` (Mode `0600`)

### Predefined Support Agents (10 Accounts)
| Agent ID | Full Name | Username | Default Password | Default Status |
| :---: | :--- | :---: | :---: | :---: |
| `AGT101` | Alice Smith | `agent1` | `agentpass1` | ACTIVE |
| `AGT102` | Bob Johnson | `agent2` | `agentpass2` | ACTIVE |
| `AGT103` | Charlie Brown | `agent3` | `agentpass3` | ACTIVE |
| `AGT104` | Diana Prince | `agent4` | `agentpass4` | ACTIVE |
| `AGT105` | Edward Stark | `agent5` | `agentpass5` | ACTIVE |
| `AGT106` | Fiona Gallagher | `agent6` | `agentpass6` | ACTIVE |
| `AGT107` | George Clark | `agent7` | `agentpass7` | ACTIVE |
| `AGT108` | Hannah Abbott | `agent8` | `agentpass8` | ACTIVE |
| `AGT109` | Ian Malcolm | `agent9` | `agentpass9` | ACTIVE |
| `AGT110` | Julia Roberts | `agent10` | `agentpass10` | ACTIVE |

---

## 4. Application-Defined Function Inventory (33 Functions)

All 33 functions are implemented in [`src/main.c`](file:///c:/Users/likhi/OneDrive/Desktop/poc/src/main.c):

| # | Function Signature | Description |
| :-: | :--- | :--- |
| 1 | `void getTimestamp(char *buffer, size_t size)` | Formats current timestamp `YYYY-MM-DD HH:MM:SS` |
| 2 | `void readString(const char *prompt, char *buffer, size_t size)` | Reads line, strips newlines, sanitizes delimiter pipes |
| 3 | `int readInt(const char *prompt, int minVal, int maxVal)` | Bounded integer validation with reprompting |
| 4 | `int hashPassword(const char *password, const char *saltHex, int iterations, char *outHash, size_t outSize)` | PBKDF2-HMAC-SHA256 password hashing with OpenSSL CSPRNG |
| 5 | `int verifyPassword(const char *password, const char *storedHash)` | Constant-time password verification & legacy detection |
| 6 | `CustomerNode* findCustomerByUsername(const char *username)` | Looks up customer node by username |
| 7 | `ComplaintNode* findComplaintById(const char *complaintId)` | Looks up complaint node by ID |
| 8 | `void addAuditEntry(ComplaintNode *node, const char *action, const char *by, const char *details)` | Appends immutable audit entry to complaint |
| 9 | `int autoAssignAgent(void)` | Least-loaded active agent selection algorithm |
| 10 | `void initSystem(void)` | Loads data files, migrates legacy records, seeds state |
| 11 | `saveAllData(void)` | Atomically writes data files with strict 0600 permissions |
| 12 | `void freeAllMemory(void)` | Deallocates all linked lists and dynamic memory |
| 13 | `void* monitoringThread(void *arg)` | Background monitoring thread with timed wait |
| 14 | `void customerMenu(void)` | Customer portal authentication menu |
| 15 | `void customerRegister(void)` | Customer account registration with PBKDF2 |
| 16 | `void customerLogin(void)` | Customer login and legacy migration |
| 17 | `void customerDashboard(const char *customerId, const char *customerName)` | Customer session menu dispatch |
| 18 | `void customerRegisterComplaint(const char *customerId)` | Complaint intake and automatic agent assignment |
| 19 | `void customerViewComplaints(const char *customerId)` | Summarized complaint listing for authenticated customer |
| 20 | `void customerTrackComplaint(const char *customerId)` | Detailed progress timeline with authorization check |
| 21 | `void customerViewHistory(const char *customerId)` | Chronological audit history with authorization check |
| 22 | `void agentMenu(void)` | Agent portal authentication and status check |
| 23 | `void agentDashboard(int agentIdx)` | Agent session dashboard and metric calculation |
| 24 | `void agentViewAssigned(const char *agentId)` | Assigned ticket listing for logged-in agent |
| 25 | `void agentUpdateComplaint(const char *agentId)` | Agent status updates (`IN_PROGRESS`, `RESOLVED`, `ESCALATED`) |
| 26 | `void managerMenu(void)` | Manager login interface |
| 27 | `void managerDashboard(void)` | 7-option master manager operations dashboard |
| 28 | `void managerViewAllComplaints(void)` | Full system complaint dashboard and KPI metrics |
| 29 | `void managerViewEscalatedComplaints(void)` | Dedicated filter for `ESCALATED` complaints |
| 30 | `void managerAssignComplaint(void)` | Manual assignment/reassignment of tickets to agents |
| 31 | `void managerUpdateComplaint(void)` | Manager status override and closure |
| 32 | `void managerAgentManagement(void)` | Support agent workload inspection and active toggling |
| 33 | `int main(void)` | Application lifecycle, thread management, and shutdown |

---

## 5. Linux Build & Verification Guide

### Prerequisites
On Ubuntu / Debian / HCL Linux:
```bash
sudo apt-get update
sudo apt-get install -y gcc g++ make cmake libssl-dev libgtest-dev valgrind cppcheck gcovr
```

### Build & Execution Commands
```bash
# 1. Build optimized release binary
make release

# 2. Build debug binary with debug symbols
make debug

# 3. Execute Google Test suite (70 tests)
make test

# 4. Generate code coverage report (gcovr)
make coverage

# 5. Run Valgrind Memcheck
make valgrind

# 6. Run Valgrind Helgrind thread safety verification
make helgrind

# 7. Run Cppcheck static analysis
make cppcheck

# 8. Run the production application
make run
```

---

## 6. Generated Reports & Audit Trails

Complete documentation and verification artifacts are located in [`reports/`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/):
- [`reports/function_inventory.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/function_inventory.md): All 33 functions with signatures, lines, logic, and 3 test cases each.
- [`reports/test_case_matrix.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/test_case_matrix.md): All 70 Google Test cases with IDs, scenarios, expected results, and status.
- [`reports/password_security_report.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/password_security_report.md): PBKDF2 specifications, salt generation, migration, and permission hardening.
- [`reports/escalated_complaints_report.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/escalated_complaints_report.md): Manager portal escalated complaints design, formatting, and tests.
- [`reports/coverage_report.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/coverage_report.md): GCC gcov/gcovr metrics (75% lines, 77.58% branches, 100% functions).
- [`reports/valgrind_report.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/valgrind_report.md): Valgrind Memcheck log showing 0 errors, 0 memory leaks.
- [`reports/helgrind_report.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/helgrind_report.md): Helgrind thread safety analysis showing 0 data races.
- [`reports/final_verification_report.md`](file:///c:/Users/likhi/OneDrive/Desktop/poc/reports/final_verification_report.md): Final acceptance matrix across all criteria.
